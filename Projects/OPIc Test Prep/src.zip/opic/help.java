package opic;

public class help {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 3;
		String str = 1+i+"";
		System.out.println(str);
	}

}
