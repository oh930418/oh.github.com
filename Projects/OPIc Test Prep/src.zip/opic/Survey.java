package opic;

import java.awt.Button;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;

class Survey extends JFrame{
	JPanel pn;
	JPanel real = new JPanel();
	JPanel starting;
	Survey(int x, int y, JPanel m_P, CardLayout cardLayoutSet){
		pn = new JPanel();
		JPanel pn2 = new JPanel();
		JPanel starting1 = new MyPanel(1, x, y, cardLayoutSet, m_P);
		JPanel starting2 = new MyPanel(2, x, y, cardLayoutSet, m_P);
		JPanel starting3 = new MyPanel(3, x, y, cardLayoutSet, m_P);
		JPanel starting4 = new MyPanel(4, x, y, cardLayoutSet, m_P);
		JPanel starting5 = new MyPanel(5, x, y, cardLayoutSet, m_P);
		JPanel mid = new MyPanel(49, x, y, cardLayoutSet, m_P);
		JPanel end = new MyPanel(97, x, y, cardLayoutSet, m_P);

		
		
		
		m_P.add(starting1, "s1");
		m_P.add(starting2, "s2");
		m_P.add(starting3, "s3");
		m_P.add(starting4, "s4");
		m_P.add(starting5, "s5");
		m_P.add(mid, "mid");
		m_P.add(end, "15");

		cardLayoutSet.show(m_P, "s1");
		
		pn2.setLayout(null);
		real.setLayout(null);
		//pn.setLayout(new GridLayout(20, 1));
		JScrollPane scroll;
        scroll = new JScrollPane(pn);  
        scroll.setBounds(25,25,x-50,y-70);
        scroll.setBackground(Color.white);

        // real.add(scroll);
        pn.setLayout(new GridLayout(50,1));
//        pn.add(pn2);

        pn.setBackground(Color.WHITE);
		scroll.setViewportView(pn);
		JRadioButton j[] = new JRadioButton[12];
		ButtonGroup bg1 = new ButtonGroup();
		ButtonGroup bg2 = new ButtonGroup();
		ButtonGroup bg3 = new ButtonGroup();
		
///
		
	///	
		int b_x = (int) (x*0.05);
		int b_y = (int) (y*0.05);
		for(int i = 0; i < 12; i++){
			j[i] = new JRadioButton(i+"��° ��ư");
			j[i].setBackground(Color.white);
			j[i].setBounds(b_x, b_y+ (i*40), 100, 40);
			pn.add(j[i]);
			if(i == 4 || i == 6){
			//
				pn.add(new Button(" "));
				b_y += 50;
			}
			if(i<5){
				bg1.add(j[i]);
			}
			else if(i<7){
				bg2.add(j[i]);
			}
			else{
				bg3.add(j[i]);
			}
		}
		for(int i = 0; i < 2; i++){
			pn.add(new Label(" "));

		}
		Button next_btn = new Button("next");
		pn.add(next_btn);
		next_btn.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				cardLayoutSet.show(m_P, "0");

			}
			
			
		});
		
		//	add(real);
		real.add(scroll);
		//setVisible(true);
		//setSize(x, y);

	}
	class MyPanel extends JPanel {

		ImageIcon image1 = new ImageIcon();
		Image img1;
	    int x, y;
	    JButton next_btn;
	    
	    public MyPanel(int num, int screan_x, int screan_y, CardLayout cardLayoutSet, JPanel m_P){
	/*    	int x2 = (int) (screan_x*0.5)+180;
	    	int y2 = (int) (screan_y*0.5)+50;*/
	    	int x2 = (int) (screan_x*0.5)+180;
	    	int y2 = (int) (screan_y*0.5)+120;
	    	x = screan_x;
	    	y = screan_y;
	    	image1 = new ImageIcon("JOPIC/JennyOPIc_Mock_Format_Sample.00"+num+".jpeg");
	    	img1 = image1.getImage();
			setBackground(new Color(201, 205, 208));
			setLayout(null);
			
			if(num == 1){
				next_btn = new JButton("");
				next_btn.setBounds(x2, y2-68, 150, 50);
				next_btn.setBorderPainted(false);
				next_btn.setFocusPainted(false);
				next_btn.setContentAreaFilled(false);
				next_btn.setForeground(Color.BLACK);
			}
			else if(num == 49){
				next_btn = new JButton("");
				next_btn.setBounds(x2-60, y2-125, 110, 100);
				next_btn.setBorderPainted(false);
				next_btn.setFocusPainted(false);
				next_btn.setContentAreaFilled(false);
				next_btn.setForeground(Color.BLACK);

			}
			else if(num == 97){
				
				next_btn = new JButton("");
				next_btn.setBounds(x2/2+250, y2-38, 150, 50);
				next_btn.setBorderPainted(false);
				next_btn.setFocusPainted(false);
				next_btn.setContentAreaFilled(false);
				next_btn.setForeground(Color.BLACK);

			}
			else{
				next_btn = new JButton(new ImageIcon("JOPIC/next.jpg"));
				next_btn.setBorderPainted(false);
				next_btn.setFocusPainted(false);
				next_btn.setContentAreaFilled(false);
				next_btn.setForeground(Color.BLACK);
				next_btn.setBounds(x2-20, y2, 150, 50);
			}
			add(next_btn);
			
			next_btn.addActionListener(new ActionListener(){

				@Override
				public void actionPerformed(ActionEvent arg0) {
					// TODO Auto-generated method stub
					cardLayoutSet.show(m_P, "s"+(num+1));
					if(num == 2){
						cardLayoutSet.show(m_P, "0");
		
					}
					else if(num == 49){
						cardLayoutSet.show(m_P, "7");

					}
					else if(num == 97){
						System.exit(0);
					}

				}
				
				
			});
	    	
	    	
	    }
	    
	    public void paintComponent(Graphics g){//�׸��̳� ������ ������ �⺻������ ���Ǵ� ����Ʈ������Ʈ
	       super.paintComponent(g);
	       
	       g.drawImage(img1, x/2-360, y/2-225, 720, 450, this);//(�̹���, ��ġx, ��ġy, ũ��x, ũ��y, this)
	     
	    }
	 }



}

