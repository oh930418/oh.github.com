package opic;

import java.awt.Button;
import java.awt.CardLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class Test extends JFrame{
	int MAX = 10;
	JPanel m_P = new JPanel();
	JPanel p[] = new JPanel[MAX];
	//Button btn[] = new Button[10];
	String str;
	
	CardLayout cardLayoutSet = new CardLayout();
	
	Test(){
		m_P.setLayout(cardLayoutSet);
		

		for(int i = 0; i < MAX; i++){
			str = i+"";
			
			p[i] = new JPanel();
			
			Button btn = new Button(str);
			
			m_P.add(p[i], str);
			btn.setBounds(222, 400, 400, 400);

			p[i].add(btn);

			str = (i+1)+"";
			btn.addActionListener(new ActionListener(){
				//@Override
				public void actionPerformed(ActionEvent arg0) {
					// TODO Auto-generated method stub
					String next;
					next = btn.getLabel();

					int n = Integer.parseInt(next);
					n += 1;
					cardLayoutSet.show(m_P, n+"");
				}
				
			});
			
		}
		
		add(m_P);		
		
		
		setTitle("OPIC");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//		setLocationRelativeTo(null);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setVisible(true);
//�̰�		getContentPane().setPreferredSize( Toolkit.getDefaultToolkit().getScreenSize());
/*		int x = getWidth();
		int y = getHeight();
		x+=5;
		y+=15;S
		setSize(x, y);*/
//�̰�		pack();
		setSize(500, 500);
		setResizable(false);
//�̰�		setLocation(0, -20);
		/*Point p = new Point(0, 0);
		SwingUtilities.convertPoirjntToScreen(p, getContentPane());
		Point l = getLocation();
		l.x -= p.x;
		l.y -= p.y;
		setLocation(l);
		*/
		//show();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Test t = new Test();
	}

}
